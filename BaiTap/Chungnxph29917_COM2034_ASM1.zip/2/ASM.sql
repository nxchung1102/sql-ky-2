﻿CREATE DATABASE QLNT
CREATE TABLE loaiNha
(
    maLoaiNha VARCHAR(10) PRIMARY KEY,
    tenLoaiNha NVARCHAR(30)
)
CREATE TABLE quan
(
    maQuan VARCHAR(10)PRIMARY KEY,
    tenQuan NVARCHAR(20)
)
CREATE TABLE nguoiDung
(
    maND VARCHAR(10)PRIMARY KEY,
    tenND NVARCHAR(30),
    gioiTinh NVARCHAR(30),
    dienThoai NVARCHAR(30),
    diaChi NVARCHAR(30),
    maQuan VARCHAR(10) REFERENCES dbo.quan(maQuan)
)
CREATE TABLE nhaTro
(
    maNhaTro VARCHAR(10)PRIMARY KEY,
    tenNhaTro NVARCHAR(30),
    maLoaiNha VARCHAR(10)REFERENCES dbo.loaiNha(maLoaiNha),
    giaPhong MONEY,
    maQuan VARCHAR(10)REFERENCES dbo.quan(maQuan),
    diaChi NVARCHAR(30),
    moTa NVARCHAR(30),
    ngayDangTin DATE,
    maND VARCHAR(10) REFERENCES dbo.nguoiDung(maND)
)

CREATE TABLE hopDongThue
(
    maND VARCHAR(10) REFERENCES dbo.nguoiDung(maND),
    maNhaTro VARCHAR(10) REFERENCES dbo.nhaTro(maNhaTro),
    ngayDen DATE,
    ngayDi DATE,
    PRIMARY KEY(maND,maNhaTro)
)
CREATE TABLE danhGia
(
    maDG VARCHAR(10)PRIMARY KEY,
    maND VARCHAR(10) REFERENCES dbo.nguoiDung(maND),
    maNhaTro VARCHAR(10),
    likes BIT,
    noiDungDG NVARCHAR(30)
)

INSERT INTO loaiNha
VALUES
    ('MaN01', N'Nhà cấp 4'),
    ('MaN02', N'Nhà cấp 3 '),
    ('MaN03', N'Nha cấp 2')
--
INSERT INTO quan
VALUES
    ('MaQ01', N'Quận 1'),
    ('MaQ02', N'Quận 2'),
    ('MaQ03', N'Quận 3'),
    ('MaQ04', N'Quận 4'),
    ('MaQ05', N'Quận 5'),
    ('MaQ06', N'Quận 6'),
    ('MaQ07', N'Quận 7'),
    ('MaQ08', N'Quận 8'),
    ('MaQ09', N'Quận 9'),
    ('MaQ10', N'Quận 10')
--
INSERT INTO nguoiDung
VALUES
    ('MaND01', N'Nguyễn Văn 01', N'Nam', N'0123456781', N'Quận 1', 'MaQ01'),
    ('MaND02', N'Nguyễn Văn 02', N'Nam', N'0123456782', N'Quận 2', 'MaQ02'),
    ('MaND03', N'Nguyễn Văn 03', N'Nam', N'0123456783', N'Quận 3', 'MaQ03'),
    ('MaND04', N'Nguyễn Văn 04', N'Nam', N'0123456784', N'Quận 4', 'MaQ04'),
    ('MaND05', N'Nguyễn Văn 05', N'Nam', N'0123456785', N'Quận 5', 'MaQ05'),
    ('MaND06', N'Nguyễn Văn 06', N'Nữ', N'0123456786', N'Quận 6', 'MaQ06'),
    ('MaND07', N'Nguyễn Văn 07', N'Nữ', N'0123456787', N'Quận 7', 'MaQ07'),
    ('MaND08', N'Nguyễn Văn 08', N'Nữ', N'0123456788', N'Quận 8', 'MaQ08'),
    ('MaND09', N'Nguyễn Văn 09', N'Nữ', N'0123456789', N'Quận 9', 'MaQ09'),
    ('MaND10', N'Nguyễn Văn 10', N'Nữ', N'0123456710', N'Quận 10', 'MaQ10')
--

INSERT INTO nhaTro
VALUES
    ('MaNT01', N'Nhà Trọ 01', 'MaN01', 1000, 'MaQ01', N'Quận 1', N'Rộng', '2023-01-01', 'MaND01'),
    ('MaNT02', N'Nhà Trọ 02', 'MaN02', 2000, 'MaQ02', N'Quận 2', N'Rộng', '2023-02-02', 'MaND02'),
    ('MaNT03', N'Nhà Trọ 03', 'MaN03', 3000, 'MaQ03', N'Quận 3', N'Vừa', '2023-03-03', 'MaND03'),
    ('MaNT04', N'Nhà Trọ 04', 'MaN01', 4000, 'MaQ04', N'Quận 4', N'Rộng', '2023-04-04', 'MaND04'),
    ('MaNT05', N'Nhà Trọ 05', 'MaN02', 5000, 'MaQ05', N'Quận 5', N'Vừa', '2023-05-05', 'MaND05'),
    ('MaNT06', N'Nhà Trọ 06', 'MaN03', 6000, 'MaQ06', N'Quận 6', N'Rộng', '2023-06-06', 'MaND06'),
    ('MaNT07', N'Nhà Trọ 07', 'MaN01', 7000, 'MaQ07', N'Quận 7', N'Rộng', '2023-07-07', 'MaND07'),
    ('MaNT08', N'Nhà Trọ 08', 'MaN02', 8000, 'MaQ08', N'Quận 8', N'Vừa', '2023-08-08', 'MaND08'),
    ('MaNT09', N'Nhà Trọ 09', 'MaN03', 9000, 'MaQ09', N'Quận 9', N'Rộng', '2023-09-09', 'MaND09'),
    ('MaNT10', N'Nhà Trọ 10', 'MaN01', 1100, 'MaQ10', N'Quận 10', N'Rộng', '2023-10-10', 'MaND10')
--

INSERT INTO hopDongThue
VALUES
    ('MaND01', 'MaNT01', '2023-01-01', '2023-01-29'),
    ('MaND02', 'MaNT02', '2023-02-01', '2023-02-27'),
    ('MaND03', 'MaNT03', '2023-03-01', '2023-04-29'),
    ('MaND04', 'MaNT04', '2023-04-01', '2023-06-29'),
    ('MaND05', 'MaNT05', '2023-05-01', '2023-08-29'),
    ('MaND06', 'MaNT06', '2023-06-01', '2023-10-29'),
    ('MaND07', 'MaNT07', '2023-07-01', '2023-07-11'),
    ('MaND08', 'MaNT08', '2023-08-01', '2023-08-15'),
    ('MaND09', 'MaNT09', '2023-09-01', '2023-09-10'),
    ('MaND10', 'MaNT10', '2023-10-01', '2023-10-25')
--

INSERT INTO danhGia
VALUES
    ('MaDG01', 'MaND01', 'MaNT01', 1, N'Tốt'),
    ('MaDG02', 'MaND02', 'MaNT02', 1, N'Khá'),
    ('MaDG03', 'MaND03', 'MaNT03', 1, N'Tốt'),
    ('MaDG04', 'MaND04', 'MaNT04', 1, N'Khá'),
    ('MaDG05', 'MaND05', 'MaNT05', 1, N'Tốt'),
    ('MaDG06', 'MaND06', 'MaNT06', 1, N'Tốt'),
    ('MaDG07', 'MaND07', 'MaNT07', 1, N'Tốt'),
    ('MaDG08', 'MaND08', 'MaNT08', 1, N'khá'),
    ('MaDG09', 'MaND09', 'MaNT09', 1, N'Tốt'),
    ('MaDG10', 'MaND10', 'MaNT10', 1, N'Tốt')

SELECT * FROM danhGia
SELECT * FROM loaiNha
SELECT * FROM quan
SELECT * FROM nhaTro
SELECT * FROM nguoiDung
SELECT * FROM hopDongThue


